This is the implementation of the "order" use case.

Order use case:
	Increase popularity of item(s) bought
	Decrease # of used supplies
	
Java GUI:
	Selecting an item and choosing "Order" will increase the popularity of the item (as reflected in ftms.xml)
	And decrease the supply of used ingredients