/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.22.0.5146 modeling language!*/

package ca.mcgill.ecse321.FTMS.model;

// line 10 "../../../../../FTMS.ump"
public class Staff
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Staff Attributes
  private String role;

  //Staff Associations
  private Schedule schedule;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Staff(String aRole, Schedule aSchedule)
  {
    role = aRole;
    if (!setSchedule(aSchedule))
    {
      throw new RuntimeException("Unable to create Staff due to aSchedule");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setRole(String aRole)
  {
    boolean wasSet = false;
    role = aRole;
    wasSet = true;
    return wasSet;
  }

  public String getRole()
  {
    return role;
  }

  public Schedule getSchedule()
  {
    return schedule;
  }

  public boolean setSchedule(Schedule aNewSchedule)
  {
    boolean wasSet = false;
    if (aNewSchedule != null)
    {
      schedule = aNewSchedule;
      wasSet = true;
    }
    return wasSet;
  }

  public void delete()
  {
    schedule = null;
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "role" + ":" + getRole()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "schedule = "+(getSchedule()!=null?Integer.toHexString(System.identityHashCode(getSchedule())):"null")
     + outputString;
  }
}