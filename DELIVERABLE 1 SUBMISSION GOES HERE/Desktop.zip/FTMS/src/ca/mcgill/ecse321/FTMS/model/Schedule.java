/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.22.0.5146 modeling language!*/

package ca.mcgill.ecse321.FTMS.model;
import java.sql.Date;

// line 14 "../../../../../FTMS.ump"
public class Schedule
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Schedule Attributes
  private Date sunday;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Schedule(Date aSunday)
  {
    sunday = aSunday;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setSunday(Date aSunday)
  {
    boolean wasSet = false;
    sunday = aSunday;
    wasSet = true;
    return wasSet;
  }

  public Date getSunday()
  {
    return sunday;
  }

  public void delete()
  {}


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "sunday" + "=" + (getSunday() != null ? !getSunday().equals(this)  ? getSunday().toString().replaceAll("  ","    ") : "this" : "null")
     + outputString;
  }
}